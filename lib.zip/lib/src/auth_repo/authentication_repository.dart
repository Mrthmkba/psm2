import 'dart:ffi';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psm_coding_files/src/auth_repo/exception/singup_exception.dart';
import 'package:psm_coding_files/src/features/authentication/screens/Welcome/welcome_screen.dart';
import 'package:psm_coding_files/src/features/authentication/screens/dashboard/main_page.dart';
import 'package:psm_coding_files/src/features/authentication/screens/login/login.dart';
import 'package:psm_coding_files/src/features/authentication/screens/signup/SignUp.dart';

class AuthenticationRepository extends GetxController{

  static AuthenticationRepository get instance => Get.find();

  //TextField Controller
  final _auth = FirebaseAuth.instance;
  late final Rx<User?> firebaseUser;
  var verificationID = ''.obs;

  @override
  void onReady(){
    firebaseUser = Rx<User?>(_auth.currentUser);
    firebaseUser.bindStream(_auth.userChanges());
    ever(firebaseUser,_setInitialScreen);
  }

  _setInitialScreen(User? user) {
    if (user == null) {
      Get.offAll(() => const LoginScreen());
    } else {
      Get.offAll(() => const MainPage());
    }
  }

  void phoneAuthentication(String phoneNo) async{
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNo,
        verificationCompleted: (credential) async{
          await _auth.signInWithCredential(credential);
        },
        codeSent: (verificationID, resendToken){
          this.verificationID.value = verificationID;
        },
        codeAutoRetrievalTimeout: (verificationID) {
          this.verificationID.value = verificationID;
        },
        verificationFailed: (e){
          if(e.code == 'invalid-phone-number'){
            Get.snackbar('Error', 'Invalid Phone Number.');
          }else{
            Get.snackbar('Error', 'Please try again.');
          }
        },
    );
  }

  Future<bool> verifyOTP(String otp) async {
    var credentials = await _auth
      .signInWithCredential(PhoneAuthProvider.credential(verificationId: verificationID.value, smsCode: otp));
    return credentials.user != null ? true:false;
    }

  Future<void> createUserWithEmailAndPassword(String email, String password,) async{
    try{
      await _auth.createUserWithEmailAndPassword(email: email, password: password);
      if (_auth.currentUser != null) {
        Get.offAll(() => const MainPage());
      } else {
        Get.to(() => const LoginScreen());
      }

    } on FirebaseAuthException catch(e){
      final ex = SignUpWithEmailAndPasswordFailure.code(e.code);
      print('FIREBASE AUTH EXCEPTION - ${ex.message}');
      throw ex;
    }catch (_){
      const ex = SignUpWithEmailAndPasswordFailure();
      print('EXCEPTION - ${ex.message}');
      throw ex;
    }
  }

  Future<void> loginUserWithEmailAndPassword(String email, String password) async{
    try{
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      if (_auth.currentUser != null) {
        Get.offAll(() => const MainPage());
      } else {
        Get.to(() => const LoginScreen());
      }
    } on FirebaseAuthException catch(e){

    }catch (_){}
  }

  Future<void> logout() async => await _auth.signOut();

}