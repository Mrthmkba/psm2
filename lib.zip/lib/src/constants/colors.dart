import 'package:flutter/material.dart';
const PrimaryColor = Colors.blueAccent;
const SecondaryColor = Colors.blue;
const AccentColor = Colors.cyan;

const WhiteColor = Colors.white;
const DarkColor = Colors.black54;
const CardColor = Colors.white70;

const OnBoardingPage1 = Colors.white;
const OnBoardingPage2 = Colors.cyan;
const OnBoardingPage3 = Colors.brown;
