import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:psm_coding_files/src/auth_repo/authentication_repository.dart';
import 'package:psm_coding_files/src/common_widget/forms/form_header.dart';
import 'package:psm_coding_files/src/features/authentication/controllers/signup_controller.dart';
import 'package:psm_coding_files/src/features/authentication/screens/fp/fp_otp/otp_screen.dart';
import 'package:psm_coding_files/src/features/authentication/screens/login/login_header.dart';
import 'package:psm_coding_files/src/utils/text_settings.dart';

import '../dashboard/main_page.dart';


class SignUpScreen extends StatelessWidget {
  const SignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(SignupController());
    final _formKey = GlobalKey<FormState>();

    return SafeArea(child:
    Scaffold(
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(10),
          child:Column(
            children: [
              const FormHeader(
                  image:("assets/logo/MainLogo1.png"),
                  title: SignUpTitle,
                  subTitle: SignUpSubTitle,
              ),
              Container(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextFormField(
                        controller: controller.fullName,
                        decoration: const InputDecoration(
                          label: Text('Full Name'),
                          hintText: "Name",
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(30.0))
                          ),
                          prefixIcon: Icon(Icons.person_3_outlined),
                        ),
                      ),
                      const SizedBox(height: 10,),
                      TextFormField(
                        controller: controller.phoneNo,
                        decoration: const InputDecoration(
                          label: Text('Phone Number'),
                          hintText: "Phone",
                          border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(30.0))

                          ),
                          prefixIcon: Icon(Icons.phone_android_outlined),
                        ),
                      ),
                      const SizedBox(height: 10,),
                      TextFormField(
                        controller: controller.email,
                        decoration: const InputDecoration(
                          label: Text('Email'),
                          hintText: "Email",
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.all(Radius.circular(30.0))
                          ),
                          prefixIcon: Icon(Icons.email_outlined),
                        ),
                      ),
                      const SizedBox(height: 10,),
                      Obx(() => TextFormField(
                        controller: controller.password,
                        obscureText: controller.isPasswordHidden.value,
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.password_rounded),
                          labelText: "Password",
                          hintText: "Password",
                          border: const OutlineInputBorder(
                              borderRadius: BorderRadius.all(
                                  Radius.circular(30.0))),
                          suffixIcon: IconButton(
                            icon: Icon(controller.isPasswordHidden.value
                                ? Icons.visibility
                                : Icons.visibility_off),
                            onPressed: () {
                              controller.togglePasswordVisibility();
                            },
                          ),
                        ),
                        // validator: (value) {
                        //   if (value == null || value.isEmpty) {
                        //     return 'Please enter your password';
                        //   } else if (value.length < 6) {
                        //     return 'Password must be at least 6 characters long';
                        //   }
                        //   return null;
                        // },
                      )),
                      const SizedBox(height: 20,),
                      SizedBox(
                        height: 50,
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blueAccent
                          ),
                            onPressed: (){
                              if(_formKey.currentState!.validate()){
                                SignupController.instance.registerUser(controller.email.text.trim(),controller.password.text.trim());
                                // SignupController.instance.phoneAuthentication(controller.phoneNo.text.trim());
                                // ssssssssssss
                              }
                            },
                            child: const Text('Sign Up ',style: TextStyle(fontSize: 20,color: Colors.white),)),
                      ),
                      const SizedBox(height: 20,),
                      const SignUpFooter(),
                    ],
                  ),
                ),

              )
            ],
          ),
        ),
      ),
    ));
  }
}


class SignUpFooter extends StatelessWidget {
  const SignUpFooter({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Text("OR"),
        const SizedBox(height: 20,),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            icon: const Image(
              image: AssetImage("assets/logo/google.jpg"),
              width:20.0,
            ),
            onPressed:(){},
            label: const Text("Sign in with Google"),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
      ],
    );
  }
}