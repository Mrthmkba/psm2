import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:psm_coding_files/src/features/authentication/controllers/login_controller.dart';
import 'package:psm_coding_files/src/features/authentication/screens/dashboard/main_page.dart';
import '../../../../utils/text_settings.dart';

import '../fp/fp_options/bottom_modelsheet.dart';
import '../fp/fp_options/fp_button.dart';

class LoginForm extends StatelessWidget {
  const LoginForm({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(LoginController());
    final _formKey = GlobalKey<FormState>();
    return Form(
        key: _formKey,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(
              controller: controller.email,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.person_2_outlined),
                labelText: "Email",
                hintText: "Email",
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(30.0)),
                ),
              ),
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: controller.password,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.password_rounded),
                labelText: "Password",
                hintText: "Password",
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(30.0))
                ),
                suffixIcon: IconButton(
                  onPressed: null,
                  icon: Icon(Icons.remove_red_eye_outlined),
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton(
                onPressed: () {
                  FpScreen.buildShowModalBottomSheet(context);
                },
                child: const Text("Forget Password"),
              ),
            ),
            SizedBox(
              height:50,
              width: double.infinity,
              child: OutlinedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent
                ),
                onPressed: () {
                if(_formKey.currentState!.validate()){
                  LoginController.instance.loginUser(controller.email.text.trim(),controller.password.text.trim());
                }
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(builder: (context) => const MainPage()),
                // );
              },
                child: const Text('LOGIN', style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),),
              ),
            ),
          ],
        ),
      ),
    );
  }
  }
