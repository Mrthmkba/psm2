import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:psm_coding_files/src/auth_repo/authentication_repository.dart';

class SignupController extends GetxController{

  static SignupController get instance => Get.find();

  //TextField Controller
final email = TextEditingController();
final password = TextEditingController();
final fullName = TextEditingController();
final phoneNo = TextEditingController();

  // Observable for password visibility toggle
  var isPasswordHidden = true.obs;

  // Toggle Password Visibility
  void togglePasswordVisibility() {
  isPasswordHidden.value = !isPasswordHidden.value;
  }

//function to call in the form
void registerUser(String email,String password){
  AuthenticationRepository.instance.createUserWithEmailAndPassword(email, password);


}
void login(String input,String password){
  AuthenticationRepository.instance.loginUserWithEmailAndPassword(input, password);
}

void phoneAuthentication(String phoneNo) {
  AuthenticationRepository.instance.phoneAuthentication(phoneNo);
}

}